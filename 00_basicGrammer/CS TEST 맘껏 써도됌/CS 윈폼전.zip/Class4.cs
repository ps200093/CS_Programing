﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_TEST_맘껏_써도됌
{
    class Class4 : Class3
    {
        static string a = "a";
        public Class4() : base(a)
        {
            
        }
    }
}
