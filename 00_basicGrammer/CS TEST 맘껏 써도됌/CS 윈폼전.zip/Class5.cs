﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_TEST_맘껏_써도됌
{
    class Class5:interface2, interface3
    {
        public void a()
        {
            Console.WriteLine("a");
        }
        public void b()
        {
            Console.WriteLine("b");
        }
        public void c()
        {
            Console.WriteLine("c");
        }
    }
}
